module.exports = { reactStrictMode: false }
