
import { useState } from 'react';
import { useRouter } from 'next/router';
export default function Login() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    const res = await fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    const data = await res.json();
    if (res.ok) {
      if (data.role === 'candidate') {
        router.push('/candidate');
      } else {
        router.push('/recruiter');
      }
    } else {
      setError(data.error || 'Error');
    }
  };
  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial' }}>
      <h1>Log In</h1>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <form onSubmit={handleSubmit}>
        <p>
          <label>Email: </label>
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
        </p>
        <p>
          <label>Password: </label>
          <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
        </p>
        <button type="submit">Log In</button>
      </form>
    </div>
  );
}
