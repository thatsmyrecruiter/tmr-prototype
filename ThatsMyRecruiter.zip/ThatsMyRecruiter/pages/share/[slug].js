
import { useState } from 'react';
export async function getServerSideProps({ params }) {
  const slug = params.slug;
  const res = await fetch(`http://localhost:3000/api/share/${slug}`);
  const data = await res.json();
  if (!res.ok) {
    return { notFound: true };
  }
  return { props: { user: data } };
}
export default function SharePage({ user }) {
  const [contact, setContact] = useState('');
  const [jobDescription, setJobDescription] = useState('');
  const [docMessage, setDocMessage] = useState('');
  const [meetingTime, setMeetingTime] = useState('');
  const [status, setStatus] = useState('');
  const submitJob = async () => {
    const res = await fetch(`/api/share/${user.slug}/job-match`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ contact, jobDescription })
    });
    const data = await res.json();
    if (res.ok) {
      setStatus('Job match submitted.');
      setJobDescription('');
    } else {
      setStatus(data.error || 'Error');
    }
  };
  const submitDocs = async () => {
    const res = await fetch(`/api/share/${user.slug}/request-docs`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ contact, message: docMessage })
    });
    const data = await res.json();
    if (res.ok) {
      setStatus('Document request sent.');
      setDocMessage('');
    } else {
      setStatus(data.error || 'Error');
    }
  };
  const submitMeeting = async () => {
    const res = await fetch(`/api/share/${user.slug}/propose-meeting`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ contact, time: meetingTime })
    });
    const data = await res.json();
    if (res.ok) {
      setStatus('Meeting proposal sent.');
      setMeetingTime('');
    } else {
      setStatus(data.error || 'Error');
    }
  };
  const sendBuddy = async () => {
    const res = await fetch('/api/buddy/request', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ candidateId: user.id })
    });
    const data = await res.json();
    if (res.ok) {
      setStatus('Buddy request sent.');
    } else {
      setStatus(data.error || 'Login required to send buddy request');
    }
  };
  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial' }}>
      <h1>{user.name}'s Profile</h1>
      <p><strong>Preferences:</strong> {user.preferences || 'No preferences specified'}</p>
      <h2>Documents</h2>
      <ul>
        {user.documents.map(doc => (
          <li key={doc.id}>{doc.filename}</li>
        ))}
      </ul>
      <h2>Contact & Proposals</h2>
      <p>
        <label>Your contact/email: </label>
        <input type="text" value={contact} onChange={(e) => setContact(e.target.value)} />
      </p>
      <p>
        <label>Job match description:</label><br />
        <textarea value={jobDescription} onChange={(e) => setJobDescription(e.target.value)} />
        <button onClick={submitJob}>Send Job Match</button>
      </p>
      <p>
        <label>Request documents message:</label><br />
        <textarea value={docMessage} onChange={(e) => setDocMessage(e.target.value)} />
        <button onClick={submitDocs}>Request Documents</button>
      </p>
      <p>
        <label>Propose meeting time:</label><br />
        <input type="datetime-local" value={meetingTime} onChange={(e) => setMeetingTime(e.target.value)} />
        <button onClick={submitMeeting}>Propose Meeting</button>
      </p>
      <p>
        <button onClick={sendBuddy}>Send Buddy-Up Request</button>
      </p>
      {status && <p style={{ color: 'green' }}>{status}</p>}
      <p>
        <a href="/signup">Sign up</a> or <a href="/login">Log in</a> to interact fully.
      </p>
    </div>
  );
}
