
import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
export default function BuddyChat() {
  const router = useRouter();
  const { buddyId } = router.query;
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');
  const [error, setError] = useState('');
  useEffect(() => {
    if (!buddyId) return;
    async function fetchMessages() {
      const res = await fetch(`/api/messages/${buddyId}`);
      const data = await res.json();
      if (res.ok) {
        setMessages(data.messages);
      } else {
        setError(data.error || 'Error');
      }
    }
    fetchMessages();
  }, [buddyId]);
  const sendMessage = async () => {
    if (!text) return;
    const res = await fetch('/api/messages/send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ buddyId, text })
    });
    const data = await res.json();
    if (res.ok) {
      setText('');
      const res2 = await fetch(`/api/messages/${buddyId}`);
      const data2 = await res2.json();
      if (res2.ok) setMessages(data2.messages);
    } else {
      setError(data.error || 'Error sending message');
    }
  };
  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial' }}>
      <h1>Conversation with {buddyId}</h1>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <div style={{ border: '1px solid #ccc', padding: '1rem', height: '300px', overflowY: 'auto' }}>
        {messages.map((msg) => (
          <div key={msg.id} style={{ marginBottom: '0.5rem' }}>
            <strong>{msg.senderId === buddyId ? buddyId : 'You'}:</strong> {msg.text}
          </div>
        ))}
      </div>
      <p>
        <input type="text" value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') sendMessage(); }} />
        <button onClick={sendMessage}>Send</button>
      </p>
      <p><button onClick={() => router.back()}>Back</button></p>
    </div>
  );
}
