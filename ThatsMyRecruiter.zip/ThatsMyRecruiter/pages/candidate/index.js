
import { useState, useEffect } from 'react';
import Router from 'next/router';
import Link from 'next/link';
export default function CandidateDashboard() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [shareSlug, setShareSlug] = useState(null);
  const [buddyRequests, setBuddyRequests] = useState([]);
  const [buddies, setBuddies] = useState([]);
  useEffect(() => {
    async function fetchMe() {
      const res = await fetch('/api/me');
      if (res.ok) {
        const data = await res.json();
        if (data.role !== 'candidate') {
          Router.push('/');
          return;
        }
        setUser(data);
        setShareSlug(data.shareSlug);
        setBuddyRequests(data.buddyRequests || []);
        setBuddies(data.buddies || []);
      } else {
        Router.push('/login');
      }
      setLoading(false);
    }
    fetchMe();
  }, []);
  const handleUpload = async (e) => {
    e.preventDefault();
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64 = reader.result.split(',')[1];
      setUploading(true);
      const res = await fetch('/api/candidate/documents', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filename: file.name, content: base64 })
      });
      const data = await res.json();
      if (res.ok) {
        setUser(data);
      }
      setUploading(false);
    };
    reader.readAsDataURL(file);
  };
  const handleCreateShare = async () => {
    const res = await fetch('/api/share/create', { method: 'POST' });
    const data = await res.json();
    if (res.ok) {
      setShareSlug(data.slug);
    }
  };
  const handleAcceptBuddy = async (id) => {
    const res = await fetch('/api/buddy/accept', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ recruiterId: id })
    });
    const data = await res.json();
    if (res.ok) {
      setBuddyRequests(data.buddyRequests);
      setBuddies(data.buddies);
    }
  };
  if (loading) return <p style={{padding:'2rem'}}>Loading...</p>;
  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial' }}>
      <h1>Candidate Dashboard</h1>
      <p>Welcome, {user.name}</p>
      <h2>Documents</h2>
      <ul>
        {user.documents.map(doc => (
          <li key={doc.id}>{doc.filename}</li>
        ))}
      </ul>
      <form onSubmit={handleUpload}>
        <input type="file" onChange={(e) => setFile(e.target.files[0])} />
        <button type="submit" disabled={uploading}>Upload</button>
      </form>
      <h2>Share Link</h2>
      {shareSlug ? (
        <p>
          Share URL: <a href={`/share/${shareSlug}`} target="_blank" rel="noopener noreferrer">/share/{shareSlug}</a>
        </p>
      ) : (
        <button onClick={handleCreateShare}>Generate Share Link</button>
      )}
      <h2>Buddy Requests</h2>
      {buddyRequests.length === 0 ? (
        <p>No requests</p>
      ) : (
        <ul>
          {buddyRequests.map(id => (
            <li key={id}>{id} <button onClick={() => handleAcceptBuddy(id)}>Accept</button></li>
          ))}
        </ul>
      )}
      <h2>Buddies</h2>
      {buddies.length === 0 ? (
        <p>No buddies yet</p>
      ) : (
        <ul>
          {buddies.map(id => (
            <li key={id}><Link href={`/buddy/${id}`}>{id}</Link></li>
          ))}
        </ul>
      )}
      <p>
        <button onClick={() => fetch('/api/logout').then(() => Router.push('/'))}>Logout</button>
      </p>
    </div>
  );
}
