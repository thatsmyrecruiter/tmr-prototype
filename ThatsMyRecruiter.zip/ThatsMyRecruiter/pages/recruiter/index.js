
import { useState, useEffect } from 'react';
import Router from 'next/router';
import Link from 'next/link';
export default function RecruiterDashboard() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [candidateId, setCandidateId] = useState('');
  const [shareSlug, setShareSlug] = useState('');
  const [buddies, setBuddies] = useState([]);
  useEffect(() => {
    async function fetchMe() {
      const res = await fetch('/api/me');
      if (res.ok) {
        const data = await res.json();
        if (data.role !== 'recruiter') {
          Router.push('/');
          return;
        }
        setUser(data);
        setBuddies(data.buddies || []);
      } else {
        Router.push('/login');
      }
      setLoading(false);
    }
    fetchMe();
  }, []);
  const handleBuddyRequest = async () => {
    if (!candidateId) return;
    const res = await fetch('/api/buddy/request', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ candidateId })
    });
    const data = await res.json();
    if (res.ok) {
      alert('Buddy request sent');
      setCandidateId('');
    } else {
      alert(data.error || 'Error sending request');
    }
  };
  if (loading) return <p style={{padding:'2rem'}}>Loading...</p>;
  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial' }}>
      <h1>Recruiter Dashboard</h1>
      <p>Welcome, {user.name}</p>
      <h2>Open Share</h2>
      <p>
        <input type="text" placeholder="Share slug" value={shareSlug} onChange={(e) => setShareSlug(e.target.value)} />
        {shareSlug && <Link href={`/share/${shareSlug}`}><button>Open</button></Link>}
      </p>
      <h2>Send Buddy Request</h2>
      <p>
        <input type="text" placeholder="Candidate ID" value={candidateId} onChange={(e) => setCandidateId(e.target.value)} />
        <button onClick={handleBuddyRequest}>Send Request</button>
      </p>
      <h2>Buddies</h2>
      {buddies.length === 0 ? (
        <p>No buddies yet</p>
      ) : (
        <ul>
          {buddies.map(id => (
            <li key={id}><Link href={`/buddy/${id}`}>{id}</Link></li>
          ))}
        </ul>
      )}
      <p>
        <button onClick={() => fetch('/api/logout').then(() => Router.push('/'))}>Logout</button>
      </p>
    </div>
  );
}
