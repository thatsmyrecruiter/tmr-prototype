
import { verifySession, generateId } from '../../../lib/auth';
import { readDb, writeDb } from '../../../lib/db';
import parseCookies from '../../../utils/parseCookies';
export default function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).end();
    return;
  }
  const cookies = parseCookies(req);
  const user = verifySession(cookies.session);
  if (!user || user.role !== 'candidate') {
    res.status(401).json({ error: 'Unauthorized' });
    return;
  }
  const slug = generateId().slice(0, 8);
  const db = readDb();
  const u = db.users.find(u => u.id === user.id);
  u.shareSlug = slug;
  writeDb(db);
  res.status(200).json({ slug });
}
