
import { readDb } from '../../../lib/db';
export default function handler(req, res) {
  const { slug } = req.query;
  const db = readDb();
  const user = db.users.find(u => u.shareSlug === slug);
  if (!user) {
    res.status(404).json({ error: 'Not found' });
    return;
  }
  const { id, name, preferences, documents, shareSlug } = user;
  const docs = documents.map(d => ({ id: d.id, filename: d.filename }));
  res.status(200).json({ id, name, preferences, documents: docs, slug: shareSlug });
}
