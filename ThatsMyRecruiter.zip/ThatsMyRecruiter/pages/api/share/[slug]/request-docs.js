
import { readDb, writeDb } from '../../../../lib/db';
export default function handler(req, res) {
  const { slug } = req.query;
  if (req.method !== 'POST') {
    res.status(405).end();
    return;
  }
  const { contact, message } = req.body;
  if (!contact) {
    res.status(400).json({ error: 'Missing contact' });
    return;
  }
  const db = readDb();
  const user = db.users.find(u => u.shareSlug === slug);
  if (!user) {
    res.status(404).json({ error: 'Not found' });
    return;
  }
  user.docRequests.push({ contact, message: message || '', timestamp: Date.now() });
  writeDb(db);
  res.status(200).json({ success: true });
}
