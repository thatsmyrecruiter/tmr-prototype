
import { authenticate, createSession } from '../../lib/auth';
import { setCookie } from 'nookies';
export default function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).end();
    return;
  }
  const { email, password } = req.body;
  const user = authenticate(email, password);
  if (!user) {
    res.status(401).json({ error: 'Invalid credentials' });
    return;
  }
  const session = createSession(user);
  setCookie({ res }, 'session', session, { path: '/', maxAge: 60 * 60 * 24 * 30 });
  res.status(200).json({ role: user.role });
}
