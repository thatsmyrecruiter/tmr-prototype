
import { setCookie } from 'nookies';
export default function handler(req, res) {
  setCookie({ res }, 'session', '', { path: '/', maxAge: 0 });
  res.status(200).json({ ok: true });
}
