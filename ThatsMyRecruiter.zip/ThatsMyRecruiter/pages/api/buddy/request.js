
import { verifySession } from '../../../lib/auth';
import { readDb, writeDb } from '../../../lib/db';
import parseCookies from '../../../utils/parseCookies';
export default function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).end();
    return;
  }
  const cookies = parseCookies(req);
  const user = verifySession(cookies.session);
  if (!user || user.role !== 'recruiter') {
    res.status(401).json({ error: 'Unauthorized' });
    return;
  }
  const { candidateId } = req.body;
  if (!candidateId) {
    res.status(400).json({ error: 'Missing candidateId' });
    return;
  }
  const db = readDb();
  const candidate = db.users.find(u => u.id === candidateId && u.role === 'candidate');
  if (!candidate) {
    res.status(404).json({ error: 'Candidate not found' });
    return;
  }
  if (!candidate.buddyRequests.includes(user.id) && !candidate.buddies.includes(user.id)) {
    candidate.buddyRequests.push(user.id);
  }
  const recruiter = db.users.find(u => u.id === user.id);
  if (!recruiter.buddyRequestsSent.includes(candidateId) && !recruiter.buddies.includes(candidateId)) {
    recruiter.buddyRequestsSent.push(candidateId);
  }
  writeDb(db);
  res.status(200).json({ success: true });
}
