
import { verifySession } from '../../../lib/auth';
import { readDb, writeDb } from '../../../lib/db';
import parseCookies from '../../../utils/parseCookies';
export default function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).end();
    return;
  }
  const cookies = parseCookies(req);
  const user = verifySession(cookies.session);
  if (!user || user.role !== 'candidate') {
    res.status(401).json({ error: 'Unauthorized' });
    return;
  }
  const { recruiterId } = req.body;
  if (!recruiterId) {
    res.status(400).json({ error: 'Missing recruiterId' });
    return;
  }
  const db = readDb();
  const candidate = db.users.find(u => u.id === user.id);
  const recruiter = db.users.find(u => u.id === recruiterId && u.role === 'recruiter');
  if (!recruiter) {
    res.status(404).json({ error: 'Recruiter not found' });
    return;
  }
  const reqIndex = candidate.buddyRequests.indexOf(recruiterId);
  if (reqIndex === -1) {
    res.status(400).json({ error: 'No such request' });
    return;
  }
  candidate.buddyRequests.splice(reqIndex, 1);
  candidate.buddies.push(recruiterId);
  recruiter.buddies.push(candidate.id);
  const sentIndex = recruiter.buddyRequestsSent.indexOf(candidate.id);
  if (sentIndex !== -1) recruiter.buddyRequestsSent.splice(sentIndex, 1);
  writeDb(db);
  res.status(200).json({ buddyRequests: candidate.buddyRequests, buddies: candidate.buddies });
}
