
import { verifySession } from '../../lib/auth';
import parseCookies from '../../utils/parseCookies';
export default function handler(req, res) {
  const cookies = parseCookies(req);
  const session = cookies.session;
  const user = verifySession(session);
  if (!user) {
    res.status(401).json({ error: 'Not authenticated' });
    return;
  }
  const { passwordHash, ...safeUser } = user;
  res.status(200).json(safeUser);
}
