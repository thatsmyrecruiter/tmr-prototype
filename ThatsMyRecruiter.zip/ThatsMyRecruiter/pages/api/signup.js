
import { createUser } from '../../lib/auth';
export default function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).end();
    return;
  }
  const { role, name, email, password } = req.body;
  if (!role || !name || !email || !password) {
    res.status(400).json({ error: 'Missing fields' });
    return;
  }
  try {
    createUser(role, name, email, password);
    res.status(200).json({ success: true });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
}
