
import { verifySession, generateId } from '../../../lib/auth';
import { readDb, writeDb } from '../../../lib/db';
import parseCookies from '../../../utils/parseCookies';
export default function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).end();
    return;
  }
  const cookies = parseCookies(req);
  const user = verifySession(cookies.session);
  if (!user) {
    res.status(401).json({ error: 'Unauthorized' });
    return;
  }
  const { buddyId, text } = req.body;
  if (!buddyId || !text) {
    res.status(400).json({ error: 'Missing parameters' });
    return;
  }
  const db = readDb();
  const me = db.users.find(u => u.id === user.id);
  const buddy = db.users.find(u => u.id === buddyId);
  if (!buddy || !me.buddies.includes(buddyId)) {
    res.status(400).json({ error: 'Not buddies' });
    return;
  }
  const message = { id: generateId(), senderId: me.id, text, timestamp: Date.now() };
  if (!me.messages[buddyId]) me.messages[buddyId] = [];
  if (!buddy.messages[me.id]) buddy.messages[me.id] = [];
  me.messages[buddyId].push(message);
  buddy.messages[me.id].push(message);
  writeDb(db);
  res.status(200).json({ success: true });
}
