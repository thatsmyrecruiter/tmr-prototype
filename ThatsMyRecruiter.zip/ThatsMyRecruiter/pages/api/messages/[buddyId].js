
import { verifySession } from '../../../lib/auth';
import { readDb } from '../../../lib/db';
import parseCookies from '../../../utils/parseCookies';
export default function handler(req, res) {
  const { buddyId } = req.query;
  const cookies = parseCookies(req);
  const user = verifySession(cookies.session);
  if (!user) {
    res.status(401).json({ error: 'Unauthorized' });
    return;
  }
  const db = readDb();
  const me = db.users.find(u => u.id === user.id);
  if (!me || !me.buddies.includes(buddyId)) {
    res.status(400).json({ error: 'Not buddies' });
    return;
  }
  const msgs = me.messages[buddyId] || [];
  msgs.sort((a,b) => a.timestamp - b.timestamp);
  res.status(200).json({ messages: msgs });
}
