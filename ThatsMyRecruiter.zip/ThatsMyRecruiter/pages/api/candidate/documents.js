
import { verifySession, generateId } from '../../../lib/auth';
import { readDb, writeDb } from '../../../lib/db';
import parseCookies from '../../../utils/parseCookies';
export default function handler(req, res) {
  const cookies = parseCookies(req);
  const session = cookies.session;
  const user = verifySession(session);
  if (!user || user.role !== 'candidate') {
    res.status(401).json({ error: 'Unauthorized' });
    return;
  }
  if (req.method === 'GET') {
    const { passwordHash, ...safeUser } = user;
    res.status(200).json(safeUser.documents || []);
    return;
  }
  if (req.method === 'POST') {
    const { filename, content } = req.body;
    if (!filename || !content) {
      res.status(400).json({ error: 'Missing file' });
      return;
    }
    const db = readDb();
    const u = db.users.find(u => u.id === user.id);
    const doc = { id: generateId(), filename, content, uploadedAt: Date.now() };
    u.documents.push(doc);
    writeDb(db);
    const { passwordHash, ...safeUser } = u;
    res.status(200).json(safeUser);
    return;
  }
  res.status(405).end();
}
