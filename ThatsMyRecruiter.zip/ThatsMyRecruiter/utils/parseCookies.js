
function parseCookies(req) {
  const cookie = req.headers.cookie || '';
  const result = {};
  cookie.split(';').forEach(part => {
    const [k, v] = part.trim().split('=');
    if (k) result[k] = decodeURIComponent(v);
  });
  return result;
}
module.exports = parseCookies;
